Arduino IDE would not work with ESP32 boards out-the-box. ESP32-EVB and the rest of the Olimex-made ESP32 boards are supported by this Arduino for ESP32 package. You need to install ESP32 support in Arduino IDE, follow the advice here: 

https://docs.espressif.com/projects/arduino-esp32/en/latest/installing.html

After the package is installed select the ESP32-EVB entry from the board selector and the COM port it was assigned by your operating system.
